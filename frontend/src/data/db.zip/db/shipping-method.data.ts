import {ShippingMethodEnum} from "../../enum";
import {ShippingMethodDbType} from "../../interface";

export const shippingMethods: Array<ShippingMethodDbType> = [
    {
        id: ShippingMethodEnum.freeShipping,
        price: 0,
        name: {"en-US": "Free Shipping", "uk-UA": "Безкоштовна доставка"},
        info: {
            "en-US": "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
            "uk-UA": "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
        },
        createdAt: "2023-02-03T17:46:00.924Z",
        changedAt: "2023-02-03T17:46:00.924Z",
    },
    {
        id: ShippingMethodEnum.standard,
        price: 40,
        name: {"en-US": "Standard", "uk-UA": "Стандарт"},
        info: {
            "en-US": "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
            "uk-UA": "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
        },
        createdAt: "2023-02-03T17:46:00.924Z",
        changedAt: "2023-02-03T17:46:00.924Z",
    },
]
