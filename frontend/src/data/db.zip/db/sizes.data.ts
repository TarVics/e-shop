import {SizeDbType} from "../../interface";

export const sizesData: Array<SizeDbType> = [
    {
        id: '1',
        name: {"en-US": "XXS", "uk-UA": "XXS"},
        createdAt: "2023-02-03T17:46:00.924Z",
        changedAt: "2023-02-03T17:46:00.924Z",
    },
    {
        id: '2',
        name: {"en-US": "XS", "uk-UA": "XS"},
        createdAt: "2023-02-03T17:46:00.924Z",
        changedAt: "2023-02-03T17:46:00.924Z",
    },
    {
        id: '3',
        name: {"en-US": "S", "uk-UA": "S"},
        createdAt: "2023-02-03T17:46:00.924Z",
        changedAt: "2023-02-03T17:46:00.924Z",
    },
    {
        id: '4',
        name: {"en-US": "M", "uk-UA": "M"},
        createdAt: "2023-02-03T17:46:00.924Z",
        changedAt: "2023-02-03T17:46:00.924Z",
    },
    {
        id: '5',
        name: {"en-US": "L", "uk-UA": "L"},
        createdAt: "2023-02-03T17:46:00.924Z",
        changedAt: "2023-02-03T17:46:00.924Z",
    },
    {
        id: '6',
        name: {"en-US": "XL", "uk-UA": "XL"},
        createdAt: "2023-02-03T17:46:00.924Z",
        changedAt: "2023-02-03T17:46:00.924Z",
    },
    {
        id: '7',
        name: {"en-US": "XXL", "uk-UA": "XXL"},
        createdAt: "2023-02-03T17:46:00.924Z",
        changedAt: "2023-02-03T17:46:00.924Z",
    },
    {
        id: '8',
        name: {"en-US": "XXXL", "uk-UA": "XXXL"},
        createdAt: "2023-02-03T17:46:00.924Z",
        changedAt: "2023-02-03T17:46:00.924Z",
    },
];
