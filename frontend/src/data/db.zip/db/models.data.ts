import {ModelDbType} from "../../interface";

export const modelsData: Array<ModelDbType> = [
    {
        id: '1',
        name: {"en-US": "Model 1", "uk-UA": "Лінійка 1"},
        createdAt: "2023-02-03T17:46:00.924Z",
        changedAt: "2023-02-03T17:46:00.924Z",
    },
    {
        id: '2',
        name: {"en-US": "Model 2", "uk-UA": "Лінійка 2"},
        createdAt: "2023-02-03T17:46:00.924Z",
        changedAt: "2023-02-03T17:46:00.924Z",
    },
    {
        id: '3',
        name: {"en-US": "Model 3", "uk-UA": "Лінійка 3"},
        createdAt: "2023-02-03T17:46:00.924Z",
        changedAt: "2023-02-03T17:46:00.924Z",
    },
    {
        id: '4',
        name: {"en-US": "Model 4", "uk-UA": "Лінійка 4"},
        createdAt: "2023-02-03T17:46:00.924Z",
        changedAt: "2023-02-03T17:46:00.924Z",
    },
    {
        id: '5',
        name: {"en-US": "Model 5", "uk-UA": "Лінійка 5"},
        createdAt: "2023-02-03T17:46:00.924Z",
        changedAt: "2023-02-03T17:46:00.924Z",
    },
    {
        id: '6',
        name: {"en-US": "Model 6", "uk-UA": "Лінійка 6"},
        createdAt: "2023-02-03T17:46:00.924Z",
        changedAt: "2023-02-03T17:46:00.924Z",
    },
    {
        id: '7',
        name: {"en-US": "Model 7", "uk-UA": "Лінійка 7"},
        createdAt: "2023-02-03T17:46:00.924Z",
        changedAt: "2023-02-03T17:46:00.924Z",
    },
];