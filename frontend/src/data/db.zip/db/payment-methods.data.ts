import {PaymentMethodEnum} from "../../enum";
import {PaymentMethodDbType} from "../../interface";

export const paymentMethods: Array<PaymentMethodDbType> = [
    {
        id: PaymentMethodEnum.bankTransfer,
        name: {"en-US": "Direct Bank Transfer", "uk-UA": "Банківський переказ"},
        info: {
            "en-US": "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
            "uk-UA": "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
        },
        createdAt: "2023-02-03T17:46:00.924Z",
        changedAt: "2023-02-03T17:46:00.924Z",
    },
    {
        id: PaymentMethodEnum.chequePayment,
        name: {"en-US": "Cheque Payment", "uk-UA": "Оплата чеком"},
        info: {
            "en-US": "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
            "uk-UA": "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
        },
        createdAt: "2023-02-03T17:46:00.924Z",
        changedAt: "2023-02-03T17:46:00.924Z",
    },
    {
        id: PaymentMethodEnum.paypalSystem,
        name: {"en-US": "PayPal System", "uk-UA": "Система PayPal"},
        info: {
            "en-US": "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
            "uk-UA": "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
        },
        createdAt: "2023-02-03T17:46:00.924Z",
        changedAt: "2023-02-03T17:46:00.924Z",
    },
]
