import {CartDbType} from "../../interface";

export const cartsData: Array<CartDbType> = [
    {
        id: "1",
        createdAt: "2023-03-02T16:28:00.000Z",
        changedAt: "2023-03-02T16:28:00.000Z",
    },
];
