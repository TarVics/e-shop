import {OrderType} from "../../interface";
import {PaymentMethodEnum, ShippingMethodEnum} from "../../enum";

export const ordersData: Array<OrderType> = [
    {
        id: '1',
        user: '1',
        zip_code: '20345',
        country: 'country',
        city: 'city',
        address: 'address',
        shipping: ShippingMethodEnum.freeShipping,
        payments: PaymentMethodEnum.bankTransfer,
        cart: '1',
        createdAt: "2023-02-03T17:46:00.924Z",
        changedAt: "2023-02-03T17:46:00.924Z",
    },
];
