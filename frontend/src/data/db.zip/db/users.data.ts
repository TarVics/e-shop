import {UserType} from "../../interface";
import {PaymentMethodEnum, ShippingMethodEnum} from "../../enum";

export const usersData: Array<UserType> = [
    {
        id: '1',
        first_name: 'first_name',
        last_name: 'last_name',
        email: 'email@gmail.com',
        address: 'address',
        city: 'city',
        zip_code: '20345',
        tel: '+380976665544',
        country: 'country',
        password: 'password',
        shipping: ShippingMethodEnum.freeShipping,
        payments: PaymentMethodEnum.bankTransfer,
        createdAt: "2023-02-03T17:46:00.924Z",
        changedAt: "2023-02-03T17:46:00.924Z",
    },
];
