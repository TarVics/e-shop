import {CartItemDbType} from "../../interface";

export const cartItemsData: Array<CartItemDbType> = [
    {
        id: "1",
        cart: "1",
        product: "1",
        quantity: 3,
        createdAt: "2023-03-02T16:28:00.000Z",
        changedAt: "2023-03-02T16:28:00.000Z",
    },
    {
        id: "2",
        cart: "1",
        product: "2",
        quantity: 2,
        createdAt: "2023-03-02T16:28:00.000Z",
        changedAt: "2023-03-02T16:28:00.000Z",
    },
];
