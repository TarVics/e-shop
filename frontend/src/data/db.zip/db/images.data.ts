import banner01 from "../../assets/img/banner01.jpg";
import banner02 from "../../assets/img/banner02.jpg";
import banner03 from "../../assets/img/banner03.jpg";
import banner04 from "../../assets/img/banner04.jpg";
import banner05 from "../../assets/img/banner05.jpg";
import banner06 from "../../assets/img/banner06.jpg";
import banner07 from "../../assets/img/banner07.jpg";
import banner08 from "../../assets/img/banner08.jpg";
import banner09 from "../../assets/img/banner09.jpg";
import banner10 from "../../assets/img/banner10.jpg";
import banner11 from "../../assets/img/banner11.jpg";
import banner12 from "../../assets/img/banner12.jpg";
import banner13 from "../../assets/img/banner13.jpg";
import banner14 from "../../assets/img/banner14.jpg";
import banner15 from "../../assets/img/banner15.jpg";

import mainProduct01 from "../../assets/img/main-product01.jpg";
import mainProduct02 from "../../assets/img/main-product02.jpg";
import mainProduct03 from "../../assets/img/main-product03.jpg";
import mainProduct04 from "../../assets/img/main-product04.jpg";

import product01 from "../../assets/img/product01.jpg";
import product02 from "../../assets/img/product02.jpg";
import product03 from "../../assets/img/product03.jpg";
import product04 from "../../assets/img/product04.jpg";
import product05 from "../../assets/img/product05.jpg";
import product06 from "../../assets/img/product06.jpg";
import product07 from "../../assets/img/product07.jpg";
import product08 from "../../assets/img/product08.jpg";

import thumbProduct01 from "../../assets/img/thumb-product01.jpg";
import thumbProduct02 from "../../assets/img/thumb-product02.jpg";
import thumbProduct03 from "../../assets/img/thumb-product03.jpg";
import thumbProduct04 from "../../assets/img/thumb-product04.jpg";

const _images = {
    banner01,
    banner02,
    banner03,
    banner04,
    banner05,
    banner06,
    banner07,
    banner08,
    banner09,
    banner10,
    banner11,
    banner12,
    banner13,
    banner14,
    banner15,

    mainProduct01,
    mainProduct02,
    mainProduct03,
    mainProduct04,

    product01,
    product02,
    product03,
    product04,
    product05,
    product06,
    product07,
    product08,

    thumbProduct01,
    thumbProduct02,
    thumbProduct03,
    thumbProduct04,
}

export default _images;